	function calcular () {
	var resultadopan;
	var cantipan=document.getElementById("cantpan").value;
	var valipan=document.getElementById("valpan").value;
	resultadopan=cantipan*valipan;

	var resultadoleche;
	var cantileche=document.getElementById("cantleche").value;
	var valileche=document.getElementById("valeche").value;
	var resultadoleche=cantileche*valileche;

    var resultadohuevo;
	var cantihuevo=document.getElementById("canthuevo").value;
	var valihuevos=document.getElementById("valhuevo").value;
	var resultadohuevo=cantihuevo*valihuevos;

    var resultado1=resultadopan+resultadoleche+resultadohuevo 
    document.getElementById("txtsubtotal11").value=resultado1;
    


    var resultadojabon;
  	var cantijabon=document.getElementById("cantjabon").value;
  	var valijabon=document.getElementById("valjabon").value;
  	resultadojabon=cantijabon*valijabon;

  	var resultadoshampoo;
  	var cantishampoo=document.getElementById("cantshampoo").value;
  	var valishampoo=document.getElementById("valshampoo").value;
  	resultadoshampoo=cantishampoo*valishampoo;

    var resultadocrema;
  	var canticrema=document.getElementById("cantdental").value;
  	var valicrema=document.getElementById("valdental").value;
    var resultadocrema=canticrema*valicrema;
    resultado2=resultadojabon+resultadoshampoo+resultadocrema
    document.getElementById("subtotal2").value=resultado2;
    
     
   
	var iva1;
	iva1=0.19*resultado1;
    var totaliva1=iva1 ;
    document.getElementById("iva1").value=totaliva1;

    var iva2;
    iva2=0.10*resultado2;
    document.getElementById("iva2").value=iva2;

    var subtotal;
    subtotal=resultado1+resultado2;
    document.getElementById("subtotal").value=subtotal;


    var iva;
    iva=iva1+iva2;
    document.getElementById("iva").value=iva;

    var total;
    total=iva+subtotal;
    document.getElementById("total").value=total;


     
}